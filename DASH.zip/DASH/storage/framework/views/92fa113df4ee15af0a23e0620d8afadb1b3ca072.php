<?php $__env->startSection('content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>LOG | USER ACTIVITY</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active"><a href="userManagement">User Management</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('userManagement')); ?>">User Activity Log</a></li>
                </ol>
            </div>
        </div>
        
        <?php echo Toastr::message(); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example">
                                    <thead>
                                     <tr>
                                        <th>ID</th>
                                        <th>Full Name</th>
                                        <th>Email Address</th>
                                     
                                        <th>Role Name</th>
                                        <th>Modify</th>
                                       <th>Date Time</th>
                                     </tr>    
                                   </thead>
                            <?php $__currentLoopData = $activityLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($item->user_name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                   
                                    <td><?php echo e($item->role_name); ?></td>
                                    <td><?php echo e($item->modify_user); ?></td>
                                    <td><?php echo e($item->date_time); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                </div>
             </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\DASH\resources\views/usermanagement/user_activity_log.blade.php ENDPATH**/ ?>