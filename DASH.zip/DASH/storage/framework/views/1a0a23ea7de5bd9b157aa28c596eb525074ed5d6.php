<?php $__env->startSection('content'); ?>
    <div class="dlabnav">
        <div class="dlabnav-scroll">
            <ul class="metismenu" id="menu">
                <li class="nav-label first">Main Menu</li>
                <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                        <i class="la la-home"></i>
                        <span class="nav-text">Dashboard</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(route('home')); ?>">Admin</a></li>
                        <li><a href="<?php echo e(route('student_dashboard')); ?>">Students</a></li>
                        <li><a href="<?php echo e(route('teacher_dashboard')); ?>">Teachers</a></li>
                        <li><a href="<?php echo e(route('parent_dashboard')); ?>">Parents</a></li>
                    </ul>
                </li>
                <li>
                    <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                        <i class="la la-user-plus"></i>
                        <span class="nav-text">Management</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(route('userManagement')); ?>">All Users</a></li>
                    </ul>
                </li>
                <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                        <i class="la la-user"></i>
                        <span class="nav-text">Professors</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="all-professors.html">All Professor</a></li>
                        <li><a href="add-professor.html">Add Professor</a></li>
                        <li><a href="edit-professor.html">Edit Professor</a></li>
                        <li><a href="professor-profile.html">Professor Profile</a></li>
                    </ul>
                </li>
                <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                        <i class="la la-users"></i>
                        <span class="nav-text">Students</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(route('all/student/list')); ?>">All Students</a></li>
                        <li><a href="<?php echo e(route('add/student/new')); ?>">Add Students</a></li>
                        <li><a href="edit-student.html">Edit Students</a></li>
                        <li><a href="about-student.html">About Students</a></li>
                    </ul>
                </li>
                <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                        <i class="la la-graduation-cap"></i>
                        <span class="nav-text">Courses</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="all-courses.html">All Courses</a></li>
                        <li><a href="add-courses.html">Add Courses</a></li>
                        <li><a href="edit-courses.html">Edit Courses</a></li>
                        <li><a href="about-courses.html">About Courses</a></li>
                    </ul>
                </li>
                <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                        <i class="la la-book"></i>
                        <span class="nav-text">Library</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="all-library.html">All Library</a></li>
                        <li><a href="add-library.html">Add Library</a></li>
                        <li><a href="edit-library.html">Edit Library</a></li>
                    </ul>
                </li>
                <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                        <i class="la la-building"></i>
                        <span class="nav-text">Departments</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="all-departments.html">All Departments</a></li>
                        <li><a href="add-departments.html">Add Departments</a></li>
                        <li><a href="edit-departments.html">Edit Departments</a></li>
                    </ul>
                </li>
                
                <li class="nav-label">Forms</li>
                <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                        <i class="la la-file-text"></i>
                        <span class="nav-text">Forms</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="form-element.html">Form Elements</a></li>
                        <li><a href="form-wizard.html">Wizard</a></li>
                        <li><a href="form-editor-summernote.html">Summernote</a></li>
                        <li><a href="form-pickers.html">Pickers</a></li>
                        <li><a href="form-validation-jquery.html">Jquery Validate</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>

    
    <div class="content-body">
        <!-- row -->
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4>All Users</h4>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active"><a href="userManagement">User Management</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo e(route('userManagement')); ?>">Users</a></li>
                    </ol>
                </div>
            </div>
            
            <?php echo Toastr::message(); ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Users List</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example" class="display" style="min-width: 845px">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Full Name</th>
                                            <th>Profile</th>
                                            <th>Email Address</th>
                                            <th>Phone Number</th>
                                            <th>Status</th>
                                            <th>Role Name</th>
                                            <th class="text-center">Modify</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="id"><?php echo e(++$key); ?></td>
                                                <td class="name"><?php echo e($item->name); ?></td>
                                                <td class="name">
                                                    <div class="avatar avatar-xl">
                                                        <img class="rounded-circle" width="35" src="<?php echo e(URL::to('/assets/images/'. $item->avatar)); ?>" alt="<?php echo e($item->avatar); ?>">
                                                    </div>
                                                </td>
                                                <td class="email"><?php echo e($item->email); ?></td>
                                                <td class="phone_number"><?php echo e($item->phone_number); ?></td>
                                                <?php if($item->status =='Active'): ?>
                                                <td class="status"><span class="badge bg-success"><?php echo e($item->status); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($item->status =='Disable'): ?>
                                                <td class="status"><span class="badge bg-danger"><?php echo e($item->status); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($item->status ==null): ?>
                                                <td class="status"><span class="badge bg-danger"><?php echo e($item->status); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($item->role_name =='Admin'): ?>
                                                <td class="role_name"><span  class="badge bg-success"><?php echo e($item->role_name); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($item->role_name =='Super Admin'): ?>
                                                <td class="role_name"><span  class="badge bg-info"><?php echo e($item->role_name); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($item->role_name =='Normal User'): ?>
                                                <td class="role_name"><span  class=" badge bg-warning"><?php echo e($item->role_name); ?></span></td>
                                                <?php endif; ?>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('user/add/new')); ?>">
                                                        <span class="btn btn-sm btn-info"><i class="la la-plus"></i></span>
                                                    </a>
                                                    <a href="<?php echo e(url('view/detail/'.$item->id)); ?>">
                                                        <span class="btn btn-sm btn-primary"><i class="la la-pencil"></i></span>
                                                    </a>  
                                                    <a href="<?php echo e(url('delete_user/'.$item->id)); ?>" onclick="return confirm('Are you sure to want to delete it?')"><span class="btn btn-sm btn-danger"><i class="la la-trash-o"></i></span></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.st_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms-main\resources\views/usermanagement/user_control.blade.php ENDPATH**/ ?>