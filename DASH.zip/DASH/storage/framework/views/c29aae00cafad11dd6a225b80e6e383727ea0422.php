<?php $__env->startSection('content'); ?>
    <!-- Content body start -->
    <div class="content-body">
        <!-- row -->
        <div class="container-fluid">
            <section class="row">
                <div class="col-xl-3 col-xxl-3 col-sm-6">
                    <div class="widget-stat card bg-primary">
                        <div class="card-body">
                            <div class="media">
                                <span class="mr-3">
                                    <i class="la la-users"></i>
                                </span>
                                <div class="media-body text-white">
                                    <p class="mb-1">TOTAL | Staffs</p>
                                    <h3 class="text-white"><?php echo e($staffs); ?></h3>
                                    <div class="progress mb-2 bg-white">
                                        <div class="progress-bar progress-animated bg-light" style="width: 100%"></div>
                                    </div>
                               
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-xxl-3 col-sm-6">
                    <div class="widget-stat card bg-warning">
                        <div class="card-body">
                            <div class="media">
                                <span class="mr-3">
                                    <i class="la la-user"></i>
                                </span>
                                <div class="media-body text-white">
                                    <p class="mb-1">TOTAL | Users</p>
                                    <h3 class="text-white"><?php echo e($users); ?></h3>
                                    <div class="progress mb-2 bg-white">
                                        <div class="progress-bar progress-animated bg-light" style="width: 100%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-xxl-3 col-sm-6">
                    <div class="widget-stat card bg-danger">
                        <div class="card-body">
                            <div class="media">
                                <span class="mr-3">
                                    <i class="la la-building"></i>
                                </span>
                                <div class="media-body text-white">
                                    <p class="mb-1">TOTAL | Department</p>
                                    <h3 class="text-white"><?php echo e($department); ?></h3>
                                    <div class="progress mb-2 bg-white">
                                        <div class="progress-bar progress-animated bg-light" style="width: 100%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-xxl-3 col-sm-6">
                    <div class="widget-stat card bg-secondary">
                        <div class="card-body">
                            <div class="media">
                                <span class="mr-3">
                                    <i class="la la-key"></i>
                                </span>
                                <div class="media-body text-white">
                                    <p class="mb-1">Log | Users Login</p>
                                    <h3 class="text-white"><?php echo e($activity_logs); ?></h3>
                                    <div class="progress mb-2 bg-white">
                                        <div class="progress-bar progress-animated bg-light" style="width: 100%"></div>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
            </section> 
           
            <div class="card text-center" >
                <div class="card-header">
                    <h3>Event Calendar</h3>
                </div>
                <div class="card-body" >
                   <section class="calendar">
                    <div id="calendar"style="width: 80%; display: inline-block; ">
                
                     <?php echo $__env->make('calendar.fullcalendar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                   </section>
                </div>
            
            </div>        
        </div>       

         
        </div>
        <?php echo $__env->yieldContent('menu'); ?>
        <?php echo $__env->yieldContent('content'); ?> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\directory\resources\views/dashboard/main_dashboard.blade.php ENDPATH**/ ?>