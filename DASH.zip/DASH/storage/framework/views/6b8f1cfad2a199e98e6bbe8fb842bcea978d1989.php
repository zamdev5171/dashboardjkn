

<?php $__env->startSection('content'); ?>
   
    
    <?php echo Toastr::message(); ?>

    <div class="content-body">
        <!-- header row -->
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h3> Designation </h3>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0);">Designation</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0);">View All</a></li>
                    </ol>
                </div>
            </div>
             <!-- end header -->
             <div class="row">
                 <div class="col-md-12">
                     <div class="card">
                        <div class="card-header">
                             <h4 class="card-title">Designation List</h4>
                             <a href="<?php echo e(route('add/designation/new')); ?>" class="btn btn-dark"><i class="fa fa-plus">  New</i></a>
                         </div>
                     <div class="card-body">
                         <div class="table-responsive">
                             <table id="example">
                                 <thead>
                                     <tr>
                                         <th>ID</th>
                                         <th>Designation (Gred)</th>
                                         <th class="text-center">Modify</th>
                                     </tr>
                                 </thead>
                                 <tbody>

                                     <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="id"><?php echo e(++$key); ?></td>
                                            <td class="position"><?php echo e($position->position); ?></td>
                                          

                                              <td class="text-center">
                                                 <a href="<?php echo e(url('designation/edit/'.$position->id)); ?>">
                                                <span class="btn btn-sm btn-light"><i class="fa fa-pencil"></i></span>
                                                 </a>  
                                                <a href="<?php echo e(url('delete_designation/'.$position->id)); ?>" onclick="return confirm('Are you sure want to delete it?')"><span class="btn btn-sm btn-light"><i class="fa fa-trash-o"></i></span></a>
                                             </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                             </table>
                            </div>
                         </div>
                    </div>
                </div>
             </div>  
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\directory\resources\views/designation/desg_control.blade.php ENDPATH**/ ?>