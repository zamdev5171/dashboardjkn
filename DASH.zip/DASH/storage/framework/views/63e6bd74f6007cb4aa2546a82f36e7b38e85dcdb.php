<?php $__env->startSection('content'); ?>
   
    
    <?php echo Toastr::message(); ?>

    <div class="content-body">
        <!-- header row -->
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h3>Staff Contact Directory</h3>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0);">Contact Directory</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0);">Staff</a></li>
                    </ol>
                </div>
            </div>
             <!-- end header -->

          <!-- Staff Filter -->

          <form action="<?php echo e(route('search/staff/list')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row filter-row ">
                <div class="col-sm-6 col-md-4 "> 
                    <div class="form-group form-focus">
                        <input type="text" class="form-control floating" id="name" name="fullName" placeholder=" Name">
                    </div>
                </div>
                <div class="col-sm-6 col-md-4"> 
                    <div class="form-group">
                        <select class="form-control" name="department" id="department">
                            <option selected disabled>--- Select Department---</option>
                            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($departments->department); ?>"><?php echo e($departments->department); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6 col-md-2"> 
                    <button type="sumit" class="btn btn-success btn-block"><i class= 'fa fa-search-plus'> Search</i></button>
                </div>
            </div>
        </form>
        <!-- Staff view | list -->
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item"><a href="#list-view" data-toggle="tab" class="nav-link btn-light mr-1 show active"><i class='fa fa-list'> List </i></a></li>
                        <li class="nav-item"><a href="#grid-view" data-toggle="tab" class="nav-link btn-light"><i class='fa fa-table'> Grid </i></a></li>
                    </ul>
                </div>
                <div class="col-lg-12">
                   <div class="row tab-content"> 
                        <div id="list-view" class="tab-pane fade active show col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Staff Contact List  </h4>
                                    <a href="<?php echo e(route('add/staff/new')); ?>" class="btn btn-dark"><i class='fa fa-plus'></i> New</a>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example3" class="display" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Designation</th>
                                                    <th>Department</th>
                                                    <th>Phone</th>
                                                    <th>Email</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $staffShow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><strong><?php echo e(++$key); ?></strong></td>
                                                    <td><?php echo e($staff->fullName); ?> </td>
                                                    <td><a href="javascript:void(0);"><strong><?php echo e($staff->position); ?></strong></a></td>
                                                    <td><a href="javascript:void(0);"><strong><?php echo e($staff->department); ?></strong></a></td>
                                                    <td><a href="javascript:void(0);"><strong><?php echo e($staff->phoneNumber); ?></strong></a></td>
                                                    <td><?php echo e($staff->emailAddress); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('staff/edit/'.$staff->id)); ?>" class="btn btn-sm btn-light"><i class="fa fa-pencil"></i></a>
                                                        <a href="<?php echo e(url('delete_staff/'.$staff->id)); ?>" onclick="return confirm('Are you sure want to delete it?')" class="btn btn-sm btn-light"><i class="fa fa-trash-o"></i></a>
                                                    </td>												
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="grid-view" class="tab-pane fade col-lg-12">
                            <div class="row">
                                <?php $__currentLoopData = $staffShow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="card card-profile">
                                        <div class="card-header justify-content-end pb-0">
                                            <div class="dropdown">
                                                <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                    <span class="dropdown-dots fs--1"></span>
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right border py-0">
                                                    <div class="py-2">
                                                        <a class="dropdown-item" href="<?php echo e(url('staff/edit/'.$staff->id)); ?>">Edit</a>
                                                        <a class="dropdown-item text-danger" href="<?php echo e(url('delete_staff/'.$staff->id)); ?>">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body pt-1">
                                            <div class="text-center">
                                                <h4 class="mt-4 mb-1"><?php echo e($staff->fullName); ?></h4>
                                                <p class="text-muted"><?php echo e($staff->position); ?></p>
                                                <h4 class="text-muted"><?php echo e($staff->department); ?></h4>
                                                <ul class="list-group mb-3 list-group-flush">
                                                 
                                                    <li class="list-group-item px-0 d-flex justify-content-between">
                                                        <span class="mb-0">Phone No. :</span><strong><?php echo e($staff->phoneNumber); ?></strong></li>
                                                    <li class="list-group-item px-0 d-flex justify-content-between">
                                                         <span class="mb-0">Email:</span><strong><?php echo e($staff->emailAddress); ?></strong></li> 
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\directory\resources\views/staff/staff_all.blade.php ENDPATH**/ ?>