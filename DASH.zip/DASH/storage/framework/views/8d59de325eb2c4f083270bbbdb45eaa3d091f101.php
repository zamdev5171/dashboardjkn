<?php $__env->startSection('content'); ?>
    <!-- Content body start -->
    <div class="content-body">
        <!-- row -->
        <div class="container-fluid">
            <section class="row">
                <div class="col-xl-3 col-xxl-3 col-sm-6">
                    <div class="widget-stat card bg-white">
                        <div class="card-body">
                            <div class="media">
                               <img style= "width:100px; height:100px" src="<?php echo e(URL::to('assets/icons/HR.svg')); ?>">
                
                                <div class="media-body text-black">
                                    <p class="mb-1">Sumber Manusia</p>
                                    <h3 class="text-grey"><?php echo e($jawatan->count()); ?></h3>
                                    <div class="progress mb-2 bg-blue">
                                        <div class="progress-bar progress-animated bg-dark" style="width: 100%"></div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-xxl-3 col-sm-6">
                    <div class="widget-stat card bg-white">
                        <div class="card-body">
                            <div class="media">
                               <img style= "width:85px; height:90px" src="<?php echo e(URL::to('assets/icons/fasiliti.svg')); ?>">
                
                                <div class="media-body text-black">
                                    <p class="mb-1">Fasiliti</p>
                                    <h3 class="text-grey"><?php echo e($fasiliti->count()); ?></h3>
                                    <div class="progress mb-2 bg-blue">
                                        <div class="progress-bar progress-animated bg-dark" style="width: 100%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                 <div class="col-xl-3 col-xxl-3 col-sm-6">
                    <div class="widget-stat card bg-white">
                        <div class="card-body">
                            <div class="media">
                               <img style= "width:85px; height:90px" src="<?php echo e(URL::to('assets/icons/logistik.svg')); ?>">
                
                                <div class="media-body text-black">
                                    <p class="mb-1">Logistik</p>
                                    <h3 class="text-grey"><?php echo e($fasiliti->count()); ?></h3>
                                    <div class="progress mb-2 bg-blue">
                                        <div class="progress-bar progress-animated bg-dark" style="width: 100%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-xxl-3 col-sm-6">
                    <div class="widget-stat card bg-white">
                        <div class="card-body">
                            <div class="media">
                               <img style= "width:85px; height:90px" src="<?php echo e(URL::to('assets/icons/hospital.svg')); ?>">
                
                                <div class="media-body text-black">
                                    <p class="mb-1">Katil- Hospital</p>
                                    <h3 class="text-grey"><?php echo e($fasiliti->count()); ?></h3>
                                    <div class="progress mb-2 bg-blue">
                                        <div class="progress-bar progress-animated bg-dark" style="width: 100%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section> 

            <div class="row">
                <div class="col-sm-12 col-xl-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h4 class="card-title">PERJAWATAN</h4> </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table hover table-striped table-light">
                                    <thead>
                                        <tr>
                                            <th colspan="2" >Jawatan</th >
                                            <th style="text-align:center"> Bilangan  </th >
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $jawatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="font-weight:600; font-size:16px">
                                            <td colspan="2" ><?php echo e($jawatan->jawatan); ?></td>
                                            <td style="color:grey; text-align:center"><?php echo e($jawatan->bilangan); ?></td> 
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>

                   <div class="col-sm-12 col-xl-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h4 class="card-title">FASILITI</h4> </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table hover table-striped table-light">
                                    <thead>
                                        <tr>
                                            <th colspan="2" > Fasiliti </th >
                                            <th style="text-align:center"> Bilangan </th >
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $fasiliti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fasiliti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="2"  style="font-weight:600"><?php echo e($fasiliti->fasiliti); ?></td>
                                            <td style="font-weight:600; color:dark-grey; text-align:center" ><?php echo e($fasiliti->bilangan); ?></td> 
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                  </div>
            </div>


             <div class="row">
               <div class="col-sm-12 col-xl-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h4 class="card-title">KATIL- HOSPITAL </h4> </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table hover table-striped table-light">
                                    <thead>
                                        <tr style="text-align:center">
                                            <th> Lokasi </th >
                                            <th> Bilangan  </th>
                                            <th> Isi </th>
                                            <th> Kosong </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $hospital; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="font-weight:600"><?php echo e($hospital->lokasi); ?></td>
                                            <td style="font-weight:600; color:dark-grey; text-align:center" ><?php echo e($hospital->bilangan); ?></td> 
                                            <td style="font-weight:600; color:dark-grey; text-align:center" ><?php echo e($hospital->isi); ?></td> 
                                            <td style="font-weight:600; color:dark-grey; text-align:center" ><?php echo e($hospital->kosong); ?></td> 
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                  </div>

                   <div class="col-sm-12 col-xl-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h4 class="card-title">LOGISTIK</h4> </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table hover table-striped table-light">
                                    <thead>
                                        <tr>
                                            <th colspan="2" > Logistik </th >
                                            <th style="text-align:center"> Bilangan </th >
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $logistik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logistik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="2"  style="font-weight:600"><?php echo e($logistik->logistik); ?></td>
                                            <td style="font-weight:600; color:dark-grey; text-align:center" ><?php echo e($logistik->bilangan); ?></td> 
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                  </div>
            </div>
           

               <div class="row">
                <div class="col-sm-12 col-xl-6 d-flex">
                    <div class="card card-table flex-fill">
                        <div class="card-header">
                            <h4 class="card-title">ALAT PERUBATAN</h4> </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table hover table-striped table-light">
                                    <thead>
                                        <tr>
                                            <th colspan="2" >Peralatan</th >
                                            <th style="text-align:center"> Bilangan  </th >
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $alat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="font-weight:600; font-size:16px">
                                            <td colspan="2" ><?php echo e($alat->alat); ?></td>
                                            <td style="color:grey; text-align:center"><?php echo e($alat->bilangan); ?></td> 
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>

                  
            </div>
          
            


     </div>        
    </div>       
   </div>
        <?php echo $__env->yieldContent('menu'); ?>
        <?php echo $__env->yieldContent('content'); ?> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\directory\resources\views/dashboard/main_dashboard.blade.php ENDPATH**/ ?>