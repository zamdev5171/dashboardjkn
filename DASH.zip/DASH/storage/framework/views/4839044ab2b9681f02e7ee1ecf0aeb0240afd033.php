<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login | Admin Dashboard </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(URL::to('assets/images/favicon.png')); ?>">
    <link href="<?php echo e(URL::to('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::to('assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css"> 
    <script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
    <script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
</head>

<body class="h-100">
    
    <?php echo $__env->yieldContent('content'); ?>

    
    <!-- Required vendors -->
    <script src="<?php echo e(URL::to('assets/vendor/global/global.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('assets/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('assets/js/dlabnav-init.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\sms\resources\views/layouts/app.blade.php ENDPATH**/ ?>