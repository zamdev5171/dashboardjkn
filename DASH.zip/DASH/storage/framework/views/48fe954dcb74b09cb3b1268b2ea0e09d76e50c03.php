<?php $__env->startSection('content'); ?>

    
<div class="content-body">
        <!-- row -->
    <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h3>SDMS Administrator</h3>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active"><a href="userManagement">User Management</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo e(route('userManagement')); ?>">Administrator</a></li>
                    </ol>
                </div>
            </div>
            
              <!-- Staff Filter -->

          <form action="<?php echo e(route('user/search/list')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row filter-row ">
                <div class="col-sm-6 col-md-4 "> 
                    <div class="form-group form-focus">
                        <input type="text" class="form-control floating" id="name" name="name" placeholder=" Name">
                    </div>
                </div>
                <div class="col-sm-6 col-md-4"> 
                    <div class="form-group">
                        <select class="form-control" name="role_name" id="role_name">
                            <option selected disabled>--- Select Role ---</option>
                            <?php $__currentLoopData = $role_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role_type->role_name); ?>"><?php echo e($role_type->role_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6 col-md-2"> 
                    <button type="sumit" class="btn btn-success btn-block"><i class="fa fa-search-plus"></i> Search</button>
                </div>
            </div>
         </form>
     
            
            <?php echo Toastr::message(); ?>

            
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Administrator List</h4>
                            <a href="<?php echo e(route('user/add/new')); ?>" class="btn btn-dark"><i class="fa fa-plus">  New</i></a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th> Name</th>
                                            <th> Email</th>
                                            <th> Role </th>
                                            <th class="text-center">Modify</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="id"><?php echo e(++$key); ?></td>
                                                <td class="name"><?php echo e($item->name); ?></td>
                                               
                                                <td class="email"><?php echo e($item->email); ?></td>
                                                <?php if($item->role_name =='Admin'): ?>
                                                <td class="role_name"><span  class="badge bg-success"><?php echo e($item->role_name); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($item->role_name =='Editor'): ?>
                                                <td class="role_name"><span  class="badge bg-info"><?php echo e($item->role_name); ?></span></td>
                                                <?php endif; ?>
                                             
                                                <td class="text-center">
                                                    <a href="<?php echo e(url('user/edit/'.$item->id)); ?>">
                                                        <span class="btn btn-sm btn-light"><i class="fa fa-pencil"></i></span>
                                                    </a>  
                                                    <a href="<?php echo e(url('delete_user/'.$item->id)); ?>" onclick="return confirm('Are you sure to want to delete it?')"><span class="btn btn-sm btn-light"><i class="fa fa-trash"></i></span></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</div>
 <?php $__env->stopSection(); ?>
                               
               
            
           

<?php echo $__env->make('sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\cprc\resources\views/usermanagement/user_control.blade.php ENDPATH**/ ?>