

<?php $__env->startSection('content'); ?>
   
    
    <?php echo Toastr::message(); ?>

    <div class="content-body">
        <!-- header row -->
        <div class="container-fluid">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h3>Staff Directory | HL</h3>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0);">Directory</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0);">Report</li>
                    </ol>
                </div>
            </div>
             <!-- end header -->

          <!-- Staff Filter -->

          <form action="<?php echo e(route('filter/export')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row filter-row ">
                <div class="col-sm-6 col-md-4 "> 
                    <div class="form-group form-focus">
                        <input type="text" class="form-control floating" id="name" name="fullName" placeholder="Staff Name">
                    </div>
                </div>
                <div class="col-sm-6 col-md-4"> 
                    <div class="form-group">
                        <select class="form-control" name="department" id="department">
                            <option selected disabled>--- Select Department---</option>
                            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($departments->department); ?>"><?php echo e($departments->department); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6 col-md-2"> 
                    <button type="sumit" class="btn btn-info btn-block"><i class="fa fa-search-plus"></i> Search</button>
                </div>
            </div>
        </form>


        <!-- Staff view | list -->
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item"><a href="#list-view" data-toggle="tab" class="nav-link btn-light mr-1 show active"><i class='fa fa-list'> List </i></a></li>
                        <li class="nav-item"><a href="#grid-view" data-toggle="tab" class="nav-link btn-light"><i class='fa fa-table'> Grid </i></a></li>
                    </ul>
                </div>
                <div class="col-lg-12">
                    <div class="row tab-content">
                        <div id="list-view" class="tab-pane fade active show col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Staffs List  </h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example3" class="display" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Designation</th>
                                                    <th>Department</th>
                                                    <th>Phone</th>
                                                    <th>Email</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $staffShow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><strong><?php echo e(++$key); ?></strong></td>
                                                    <td><?php echo e($staff->fullName); ?> </td>
                                                    <td><a href="javascript:void(0);"><strong><?php echo e($staff->position); ?></strong></a></td>
                                                    <td><a href="javascript:void(0);"><strong><?php echo e($staff->department); ?></strong></a></td>
                                                    <td><a href="javascript:void(0);"><strong><?php echo e($staff->phoneNumber); ?></strong></a></td>
                                                    <td><?php echo e($staff->emailAddress); ?></td>											
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="grid-view" class="tab-pane fade col-lg-12">
                            <div class="row">
                                <?php $__currentLoopData = $staffShow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="card card-profile">
                                        <div class="card-body pt-2">
                                            <div class="text-center">
                                                <h3 class="mt-4 mb-1"><?php echo e($staff->fullName); ?></h3>
                                                <p class="text-muted"><?php echo e($staff->position); ?></p>
                                                <ul class="list-group mb-3 list-group-flush">
                                                    <li class="list-group-item px-0 d-flex justify-content-between">
                                                        <span class="mb-0">Department :</span><strong><?php echo e($staff->department); ?></strong></li>
                                                    <li class="list-group-item px-0 d-flex justify-content-between">
                                                        <span class="mb-0">Phone No. :</span><strong><?php echo e($staff->phoneNumber); ?></strong></li>
                                                    <li class="list-group-item px-0 d-flex justify-content-between">
                                                         <span class="mb-0">Email:</span><strong><?php echo e($staff->emailAddress); ?></strong></li> 
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\directory\resources\views/directory/report.blade.php ENDPATH**/ ?>